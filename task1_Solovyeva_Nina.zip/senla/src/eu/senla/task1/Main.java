package eu.senla.task1;

public class Main {
    static byte stByte = 2;
    static short stShort = 19;
    static int stInt = 234;
    static long  stLong = 12547;
    static float stFloat = 369825;
    static double stDouble = 2.17;
    static char stChar = 'Q';
    static boolean stBoolean = true;

    static Byte staticB = 9;
    static Short statikS = 47;
    static Integer statikI = 789;
    static Long statikL = 41l;
    static Float statikF = 3.2f;
    static Double statikD = 0.1;
    //static Character statikC = Character.MIN_VALUE;
    static Character statikC = 1067;
    static Boolean sttatikBoo = false;
    static String statikStr= "Senla";

    public static void main(String[] args){
        Number number = new Number();
        number.setB((byte) 111); //ot -128 do 127 1b
        byte b = number.getB();
        System.out.println("byte " + b);

        number.setS((short)32500); //-32768 +32767 2b
        short s = number.getS();
        System.out.println("short "+s);

        number.setI((int)264587);
        int i = number.getI();
        System.out.println("int "+i);

        number.setL((long)5458666L);
        long l = number.getL();
        System.out.println("long "+l);

        number.setF((float)14f);
        float f = number.getF();
        System.out.println("float "+f);

        number.setD((double)457841212.3);
        double d = number.getD();
        System.out.println("double "+d);

        number.setC('S');
        char c = number.getC();
        System.out.println("char "+c);

        number.setBo((boolean) true);
        boolean boo = number.isBo();
        System.out.println("boolean "+boo);

        number.setaString("Senla");
        String aString = number.getaString();
        System.out.println("String "+aString);

        System.out.println("---------------");


        stInt = (int)stDouble;
        System.out.println("double v int "+stInt);

        stInt = 45463;
        stLong = (long)stInt;
        System.out.println("int v long "+stInt);

        char ch = 'J';
        int intCh = (int) ch;
        System.out.println("char v int "+ intCh);

        Character newCh = '$';
        System.out.println("1067 -  "+ statikC);
        System.out.println(newCh + " "+ statikStr);


        //int newInt = Integer.parseInt();
        int newInt = Integer.valueOf(123);
        System.out.println(newInt);

    }
}
